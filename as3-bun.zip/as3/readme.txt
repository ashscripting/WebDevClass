the logo is from https://app.logo.com/ website and since there are no authors, and you make your own
logo I couldn't make a proper citation.

about me picture citation:
Slater, J. (2015). Seven Tips To Improve Your About Me Page on your website. Retrieved from
https://www.themarketingsage.com/seven-tips-to-improve-the-about-me-part-of-your-site/