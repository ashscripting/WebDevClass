module.exports = {
    "URI":"mongodb+srv://ASH:ASHPass2023@user-list.un9ouvh.mongodb.net/user-list?retryWrites=true&w=majority"
}